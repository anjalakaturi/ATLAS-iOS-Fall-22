import UIKit

let greeting:String = "Hello, playground"
let greet = "Hi" //type inferenced

//type alias - simpler version of having proper type
typealias SpecialNumber = Int

var myNumber: SpecialNumber = 2

typealias Coordinate = (x: Int, y: Int)

//tuples and access
//var coordinates = (x:0, y:20)
//var coordinates: Coordinate = (x:0, y:20) //using typealias
var coordinates: Coordinate = (0, 20) //using typealias - deleting labels, defined in typealias already

coordinates.0
coordinates.1

coordinates.x
coordinates.y
print(coordinates)

func findCoordinate(coord: Coordinate){ //can use type alias as an argument type
    
}

//enumerations (enum)

enum CardinalDirection: String{
    case north, east, south, west
    
    var axis: String {
        switch self{
        case .north, .south:
            return "vertical"
        case .east, .west:
            return "horizontal"
        }
    }
    
    var description: String{
        rawValue //single line functions don't need to use return keyword
    }
}

var direction = CardinalDirection.north

switch direction{
case .north, .south:
    print("vertical")
case .east, .west:
    print("horizontal")
}

direction.axis

direction.rawValue
direction.description

//struct
struct Person {
    var firstName: String
    var lastName: String
}

var me = Person(firstName: "Sally", lastName: "The Squirrel")
print(me.firstName, me.lastName)

class Human {
    var firstName: String
    var lastName: String
    
    init (){
        firstName = ""
        lastName = ""
    }
    
    init (name: String){
        let nameComponents = name.components(separatedBy: " ")
        firstName = nameComponents.first ?? ""
        lastName = nameComponents.last ?? ""
    }
}
//Class doesn't have automatic initializer like a struct
//Unlinke struct, if vars are vars, not let, can change them even if class var is let, ex. below w Bob


let bob = Human()
let joe = Human(name:"Joe Desk")
print(joe.firstName, joe.lastName)

print(bob.lastName)
bob.lastName = "bobby"
print(bob.lastName) //can update last name even though bob is let

//more expensive to use class so use struct when u can

struct Coords{
    let x: Int
    let y: Int
    
    var description: String{
        "\(x),\(y)"
    }
    
    static var zero: Coords {
        return Coords(x:0, y:0)
    }
}

let start = Coords(x:0, y:20)
//can't change x or y bc let
var ex = Coords(x:0, y:20)
//can change x and y if they were vars but can't bc they are let (consts)

//var list = [0,2,3,4,8,93]
// datatype is Array<Int>

var list: Array<Int> = [0,2,4,6]
var listEven: [Int] = [0,2,4,6]
var list2 = [Int]()
list2.append(2)

for (index, item) in list.enumerated(){
    print("On item \(index) : \(item)")
}

var dict = [Int: String]()
var dictex2 = Dictionary<Int, String>()

dict[3] = "Three"
dict[3]
dict[4]

func doStuff() {
    
}
func doSmtg() -> Void{
    //same as above but explicitly state return type
}
func add() -> Int{
    3+4
}
func add2(a: Int, b: Int) -> Int{
    a+b
}
var num = add2(a:3,b:4)
func add3(a: Int, b: Int, _ c: Int) -> Int{ //underscore so don't need to put c: in calll to func
    a+b+c
}
var num2 = add3(a:2, b:3, 5)

//can add defualt params
func math(_ num1: Int, _ other: Int = 5)-> Int{
    num1+other
}
var calc = math(3) //uses default param
var calc1 = math(3, 4) //uses given param

//optionals
var name: String?
//name is currently nil
name = "Anjala"
type(of: name) //type is Optional<String> have to unwrap

func sayHi(name: String){
    print("Hi \(name)")
}

//sayHi(name: name) - doesn't work because optional name needs to be unwrapped
 
if let name = name{
    print("about to execute")
    sayHi(name:name)
}

let customName: String
if let name = name{
    customName = name //customName was nil but got assigned to Anjala now const
} else{
    customName = "Friend"
}

sayHi(name: customName)

let tempName = name != nil ? name! : "Friend" //don't use ! for force excalmation - program will crash if it is nil - use 174 thing or 189
let tmpName = name ?? "Friend"


func takeOptional(name: String?){
    guard let name = name else{ //use guard statements instead of bunch of if else, less nested stuff
        print("no name found")
        return
    }
    print("\(name)")
}

var tempName1: String?
tempName1 = "HelloName"
takeOptional(name: tempName1)

func takeOptional1(name: String?){
    guard let name else{ //use guard statements instead of bunch of if else, less nested stuff
        //deleted "= name" in Optional1
        print("no name found")
        return
    }
    print("\(name)")
}
takeOptional1(name: tempName1)
